import React,{Component} from 'react'

export default class Line extends Component{
  render(){
    return (
      <div>Line</div>
    )
  }
}