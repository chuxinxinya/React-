import React,{Component} from 'react'

export default class Pie extends Component{
  render(){
    return (
      <div>Pie</div>
    )
  }
}