import React, { Component } from 'react'

export default class AddUpdate extends Component {
  render() {
    return (
      <div>
        我是添加或修改页面
      </div>
    )
  }
}
