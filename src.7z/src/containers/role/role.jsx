import React,{Component} from 'react'

export default class Role extends Component{
  render(){
    return (
      <div>Role</div>
    )
  }
}