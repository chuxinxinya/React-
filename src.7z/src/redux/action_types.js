//防止编码人员犯错误，写错action的名字

//保存用户信息
export const SAVE_USER_INFO = 'save_user_info'
//删除用户信息
export const DELETE_USER_INFO = 'delete_user_info'
//保存标题
export const SAVE_TITLE = 'save_title'
//保存商品列表
export const SAVE_PROD_List = 'save_prod_list'
//保存商品分类
export const SAVE_CATEGORY_List='save_category_list'



